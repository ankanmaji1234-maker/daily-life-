HER DAILY LIFE - ANDROID PROJECT

This is an Android Studio project wrapper for the pink-and-white daily routine app.
It packages the existing app locally inside an Android WebView.

IMPORTANT:
- This ZIP is Android source code, not a compiled APK.
- This environment does not have the Android SDK/Gradle build setup required to compile and verify an APK.
- To build an APK automatically without installing Android Studio:
  1. Create/sign in to a GitHub account.
  2. Create a new repository.
  3. Upload all files/folders from this ZIP to the repository (keep .github folder).
  4. Open the repository's Actions tab.
  5. Run "Build Android APK" (or wait for the first push build).
  6. Open the successful workflow run and download the "Her-Daily-Life-APK" artifact.
  7. Extract the artifact ZIP; install app-debug.apk on your Android phone.
- Android may ask you to allow installation from that browser/file manager.

APP DATA:
The routine tracker keeps its data in the app's local WebView storage on that phone.
This does not provide automatic live sync to another phone.
